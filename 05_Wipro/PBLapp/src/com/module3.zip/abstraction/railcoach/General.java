package com.abstraction.railcoach;

public class General extends Compartment {

    @Override
    public String notice() {
        return "General Passengers.";
    }
    
}

