package com.abstraction.railcoach;

public abstract class Compartment {

    public abstract String notice();

}
