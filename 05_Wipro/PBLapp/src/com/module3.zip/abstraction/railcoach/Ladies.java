package com.abstraction.railcoach;

public class Ladies extends Compartment {

    @Override
    public String notice() {
        return "Ladies Special compartment.";
    }
    
}

