package com.abstraction.railcoach;

public class FirstClass extends Compartment {

    @Override
    public String notice() {
        return "FirstClass Passengers.";
    }
    
}
