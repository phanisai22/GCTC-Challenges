package com.Package.ship;

public class Main {

    public static void main(String[] args) {
        Cubiod cubiod = new Cubiod();
        System.out.println(cubiod.getBreadth());

    }
}
