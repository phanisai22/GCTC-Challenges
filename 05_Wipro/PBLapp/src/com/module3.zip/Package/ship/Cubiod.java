package com.Package.ship;

public class Cubiod extends Compartment{

}
