package com.Package.ship;

public abstract class Compartment {

    private int height = 23;
	private int width = 22;
    private int breadth = 45;

    public int getBreadth() {
        return breadth;
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

}
