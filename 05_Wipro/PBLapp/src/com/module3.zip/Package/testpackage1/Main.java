package com.Package.testpackage1;

import com.Package.testpackage.*;

public class Main {
    public static void main(String[] args) {
        Foundation foundation = new Foundation();
        System.out.println(foundation.var1);
        // System.out.println(foundation.var2);
        // System.out.println(foundation.var3);
        // System.out.println(foundation.var4);
    }
}
