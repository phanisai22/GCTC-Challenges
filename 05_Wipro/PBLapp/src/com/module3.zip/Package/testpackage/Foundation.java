package com.Package.testpackage;

public class Foundation {

    public int var1 = 1;
    private int var2 = 2;
    protected int var3 = 3;
    int var4 = 4;

    public int getVar2() {
        return var2;
    }

}
