package com.exceptionhandling.grade;

public class MarksException extends Exception{
    
    private static final long serialVersionUID = 1L;

    public MarksException(String message) {
        super(message);
    }
}
